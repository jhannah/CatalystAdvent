
use strict;
use warnings;
use Config::JFDI;
use Getopt::Long;
use FindBin;
use lib "$FindBin::Bin/../lib";
use StandaloneApp2;

my $id;

GetOptions(
    'id=i' => \$id,
);

die "Please use --id parameter\n" unless $id;

my $config = Config::JFDI->new( name => 'WebApp', path => "$FindBin::Bin/.." )->get;
my $dsn = $config->{'Model::DB'}{args}{dsn};

my $app1 = StandaloneApp2->new( { dsn => $dsn } );

$app1->delete( $id );
