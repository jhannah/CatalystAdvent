package WebApp::View::TT;
use strict;
use warnings;
use base 'Catalyst::View::TT';
1;
