package WebApp::Model::DB;
use strict;
use warnings;
use base 'Catalyst::Model::DBI';

sub add {
    my ( $self, $params ) = @_;

    my $first_name = $params->{first_name};
    my $last_name = $params->{last_name};
    my $email = $params->{email};

    my $dbh = $self->dbh;

    my $p = $dbh->prepare( "insert into persons(first_name, last_name, email) values(?,?,?)" );

        $p->execute( $first_name, $last_name, $email );
}

sub edit {
    my ( $self, $wanted_id, $params ) = @_;

    my $first_name = $params->{first_name};
    my $last_name = $params->{last_name};
    my $email = $params->{email};

    my $dbh = $self->dbh;

    my $p = $dbh->prepare( "update persons set first_name=?, last_name=?, email=? where id=?" );

    $p->execute( $first_name, $last_name, $email, $wanted_id );
}

sub delete {
    my ( $self, $wanted_id ) = @_;

    my $dbh = $self->dbh;

    my $p = $dbh->prepare( "delete from persons where id=?" );
    $p->execute( $wanted_id );
}

sub retrieve {
    my ( $self, $wanted_id ) = @_;

    my $dbh = $self->dbh;

    my $members;

    if ( $wanted_id ) {
        $members = $dbh->selectall_arrayref( "select * from persons where id=? order by id",
          { Slice => {} }, $wanted_id );
    }
    else {
        $members = $dbh->selectall_arrayref( "select * from persons order by id",
          { Slice => {} } );
    }

    return $members;
}

1;
