create table if not exists persons(
    id integer primary key autoincrement,
    first_name text,
    last_name text,
    email text
);
