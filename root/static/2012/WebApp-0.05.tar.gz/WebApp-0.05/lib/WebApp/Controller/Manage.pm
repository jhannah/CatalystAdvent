package WebApp::Controller::Manage;
use strict;
use warnings;
use base 'Catalyst::Controller';

sub add : Local {
    my ( $self, $c ) = @_;

    if ( $c->request->params->{submit} ) {
        my $first_name = $c->request->params->{first_name};
        my $last_name = $c->request->params->{last_name};
        my $email = $c->request->params->{email};

        my $dbh = $c->model( 'DB' )->dbh;

        my $p = $dbh->prepare( "insert into persons(first_name, last_name, email) values(?,?,?)" );

        $p->execute( $first_name, $last_name, $email );

        $c->res->redirect( "/manage" );
    }
}

sub edit : Local {
    my ( $self, $c, $wanted_id ) = @_;

    my $dbh = $c->model( 'DB' )->dbh;

    if ( $c->request->params->{submit} ) {
        my $first_name = $c->request->params->{first_name};
        my $last_name = $c->request->params->{last_name};
        my $email = $c->request->params->{email};

        my $p = $dbh->prepare( "update persons set first_name=?, last_name=?, email=? where id=?" );

        $p->execute( $first_name, $last_name, $email, $wanted_id );

        $c->res->redirect( "/manage" );
    }
    else {
        my $p = $dbh->prepare( "select first_name, last_name, email from persons where id=?" );
        $p->execute( $wanted_id );
        my ( $first_name, $last_name, $email ) = $p->fetchrow_array;

        $c->stash(
            wanted_id => $wanted_id,
            first_name => $first_name,
            last_name => $last_name,
            email => $email,
        );
    }
}

sub delete : Local {
    my ( $self, $c, $wanted_id ) = @_;

    my $dbh = $c->model( 'DB' )->dbh;
    my $p = $dbh->prepare( "delete from persons where id=?" );
    $p->execute( $wanted_id );

    $c->res->redirect( "/manage" );
}

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

    my $dbh = $c->model( 'DB' )->dbh;
    my $members = $dbh->selectall_arrayref( "select * from persons order by id", { Slice => {} } );

    $c->stash( members => $members );
}

1;
