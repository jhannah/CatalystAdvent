package WebApp::Model::DB;
use strict;
use warnings;
use base 'Catalyst::Model::DBI';
1;
