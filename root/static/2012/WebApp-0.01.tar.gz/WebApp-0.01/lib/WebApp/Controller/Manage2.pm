package WebApp::Controller::Manage2;
use strict;
use warnings;
use base 'Catalyst::Controller';
use File::Slurp ':all';

__PACKAGE__->config(
    database_file => 'd:/web/step1/WebApp/data/database_file.txt',
);

sub add : Local {
    my ( $self, $c ) = @_;

    if ( $c->request->params->{submit} ) {
        my $first_name = $c->request->params->{first_name};
        my $last_name = $c->request->params->{last_name};
        my $email = $c->request->params->{email};

        my ( @lines, $id );

        my $database_file = $self->{database_file};
        @lines = read_file( $database_file ) if -f $database_file;
        ( $id ) = $lines[-1] =~ /^(\d+)\|/ if $lines[-1];
        $id = $id ? $id + 1 : 1;

        write_file $database_file, { append => 1 },
          "$id|$first_name|$last_name|$email\n";

        $c->res->redirect( "/manage2" );
    }
    else {
        my $body = qq~<html><head><title>Add person</title></head><body>
            <form action="/manage2/add" method="post">
            First name: <input type="text" name="first_name" /><br />
            Last name: <input type="text" name="last_name" /><br />
            Email: <input type="text" name="email" /><br />
            <input type="submit" name="submit" value="Save" />
            </form></body></html>~;

        $c->response->body( $body );
    }

}

sub edit : Local {
    my ( $self, $c, $wanted_id ) = @_;

    my $database_file = $self->{database_file};

    if ( $c->request->params->{submit} ) {
        my $first_name = $c->request->params->{first_name};
        my $last_name = $c->request->params->{last_name};
        my $email = $c->request->params->{email};

        edit_file_lines { s/^$wanted_id\|.*$/$wanted_id|$first_name|$last_name|$email/ } $database_file;
        $c->res->redirect( "/manage2" );
    }
    else {
        my @raw_lines = read_file $database_file;
        chomp @raw_lines;

        my ( $id, $first_name, $last_name, $email );

        for my $raw_line ( @raw_lines ) {
            my ( $test_id ) = split( /\|/, $raw_line );
            next if $wanted_id && $wanted_id != $test_id;
            ( $id, $first_name, $last_name, $email ) = split( /\|/, $raw_line );
        }

        my $body = qq~<html><head><title>Edit person</title></head><body>
            <form action="/manage2/edit/$id" method="post">
            First name: <input type="text" name="first_name" value="$first_name" /><br />
            Last name: <input type="text" name="last_name" value="$last_name" /><br />
            Email: <input type="text" name="email" value="$email" /><br />
            <input type="submit" name="submit" value="Save" />
            </form></body></html>~;

        $c->response->body( $body );
    }

}

sub delete : Local {
    my ( $self, $c, $wanted_id ) = @_;

    my $database_file = $self->{database_file};
    edit_file_lines { $_ = '' if /^$wanted_id\|/ } $database_file;
    $c->res->redirect( "/manage2" );
}

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

    my $body = qq~<html><head><title>Persons list</title></head><body>
        <a href="/manage2/add">Add new person</a><br /><table>~;

    my $database_file = $self->{database_file};
    my @raw_lines;
    @raw_lines = read_file $database_file if -f $database_file;
    chomp @raw_lines;

    for my $raw_line ( @raw_lines ) {
            my ( $id, $first_name, $last_name, $email ) = split( /\|/, $raw_line );

        $body .= qq~<tr>
            <th>$id</th>
            <td><a href="/manage2/edit/$id">$last_name, $first_name</a></td>
            <td>$email</td>
            <td><a href="/manage2/delete/$id">delete person</a></td>
        </tr>\n~;
    }

    $body .= "</table></body></html>";

    $c->response->body( $body );
}

1;
