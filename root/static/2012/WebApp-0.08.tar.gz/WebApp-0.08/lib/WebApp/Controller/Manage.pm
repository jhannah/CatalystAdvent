package WebApp::Controller::Manage;
use strict;
use warnings;
use base 'Catalyst::Controller';

sub add : Local {
    my ( $self, $c ) = @_;

    if ( delete $c->request->params->{submit} ) {
        $c->model( 'DB::Person' )->create( $c->request->params );
        $c->res->redirect( "/manage" );
    }
}

sub edit : Local {
    my ( $self, $c, $wanted_id ) = @_;

    if ( delete $c->request->params->{submit} ) {
        $c->model( 'DB::Person' )->find( $wanted_id )->update( $c->request->params );
        $c->res->redirect( "/manage" );
    }
    else {
        my $members = $c->model( 'DB::Person' )->find( $wanted_id );

        $c->stash(
            wanted_id => $wanted_id,
            first_name => $members->first_name,
            last_name => $members->last_name,
            email => $members->email,
        );
    }
}

sub delete : Local {
    my ( $self, $c, $wanted_id ) = @_;
    $c->model( 'DB::Person' )->find( $wanted_id )->delete;
    $c->res->redirect( "/manage" );
}

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;
    my @members = $c->model( 'DB::Person' )->search( undef, { order_by => 'id' } )->all;
    $c->stash( members => \@members );
}

1;
