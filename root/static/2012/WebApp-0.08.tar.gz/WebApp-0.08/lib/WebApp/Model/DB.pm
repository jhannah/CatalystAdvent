package WebApp::Model::DB;
use strict;
use base 'Catalyst::Model::DBIC::Schema';
1;
