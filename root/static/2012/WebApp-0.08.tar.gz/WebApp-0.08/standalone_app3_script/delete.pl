
use strict;
use warnings;
use Config::JFDI;
use Getopt::Long;
use FindBin;
use lib "$FindBin::Bin/../lib";
use StandaloneApp3;

my $id;

GetOptions(
    'id=i' => \$id,
);

die "Please use --id parameter\n" unless $id;

my $config = Config::JFDI->new( name => 'WebApp', path => "$FindBin::Bin/.." )->get;
my $dsn = $config->{'Model::DB'}{connect_info}{dsn};

my $app = StandaloneApp3->connect( $dsn );

$app->resultset( 'Person' )->find( $id )->delete;
