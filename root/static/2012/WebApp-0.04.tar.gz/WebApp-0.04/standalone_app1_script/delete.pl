
use strict;
use warnings;
use Config::JFDI;
use Getopt::Long;
use FindBin;
use lib "$FindBin::Bin/../lib";
use StandaloneApp1;

my $id;

GetOptions(
    'id=i' => \$id,
);

die "Please use --id parameter\n" unless $id;

my $config = Config::JFDI->new( name => 'WebApp', path => "$FindBin::Bin/.." )->get;
my $database_file = $config->{'Model::DB'}{args}{database_file};

my $app = StandaloneApp1->new( { database_file => $database_file } );

$app->delete( $id );
