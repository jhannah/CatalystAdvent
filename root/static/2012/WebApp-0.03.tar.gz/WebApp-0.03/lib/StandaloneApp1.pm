package StandaloneApp1;

use strict;
use warnings;
use File::Slurp ':all';

sub new {
    my ( $class, $params ) = @_;
    my $self = $params;
    return bless $self, $class;
}

sub add {
    my ( $self, $params ) = @_;

    my $database_file = $self->{database_file};

    my ( @lines, $id );
    @lines = read_file( $database_file ) if -f $database_file;
    ( $id ) = $lines[-1] =~ /^(\d+)\|/ if $lines[-1];
    $id = $id ? $id + 1 : 1;

    write_file $database_file, { append => 1 },
      "$id|$params->{first_name}|$params->{last_name}|$params->{email}\n";
}

sub edit {
    my ( $self, $id, $params ) = @_;

    my $database_file = $self->{database_file};

    my $first_name = $params->{first_name};
    my $last_name = $params->{last_name};
    my $email = $params->{email};

    edit_file_lines { s/^$id\|.*$/$id|$first_name|$last_name|$email/ } $database_file;
}

sub delete {
    my ( $self, $wanted_id ) = @_;

    my $database_file = $self->{database_file};

    edit_file_lines { $_ = '' if /^$wanted_id\|/ } $database_file;
}

sub retrieve {
    my ( $self, $wanted_id ) = @_;

    my $database_file = $self->{database_file};

    my @raw_lines;
    @raw_lines = read_file $database_file if -f $database_file;
    chomp @raw_lines;

    my ( @lines, $id, $first_name, $last_name, $email );

    for my $raw_line ( @raw_lines ) {
        my ( $test_id ) = split( /\|/, $raw_line );
        next if $wanted_id && $wanted_id != $test_id;
        ( $id, $first_name, $last_name, $email ) = split( /\|/, $raw_line );

        push( @lines, {
            id => $id,
            first_name => $first_name,
            last_name => $last_name,
            email => $email,
        } );
    }

    return \@lines;
}

1;
