package WebApp::Controller::Manage;
use strict;
use warnings;
use base 'Catalyst::Controller';

sub add : Local {
    my ( $self, $c ) = @_;

    if ( $c->request->params->{submit} ) {
        $c->model( 'DB' )->add( $c->request->params );
        $c->res->redirect( "/manage" );
    }
    else {
        my $body = qq~<html><head><title>Add person</title></head><body>
            <form action="/manage/add" method="post">
            First name: <input type="text" name="first_name" /><br />
            Last name: <input type="text" name="last_name" /><br />
            Email: <input type="text" name="email" /><br />
            <input type="submit" name="submit" value="Save" />
            </form></body></html>~;

        $c->response->body( $body );
    }

}

sub edit : Local {
    my ( $self, $c, $wanted_id ) = @_;

    if ( $c->request->params->{submit} ) {
        $c->model( 'DB' )->edit( $wanted_id, $c->request->params );
        $c->res->redirect( "/manage" );
    }
    else {
        my $members = $c->model( 'DB' )->retrieve( $wanted_id );
        my $first_name = $members->[0]{first_name};
        my $last_name = $members->[0]{last_name};
        my $email = $members->[0]{email};

        my $body = qq~<html><head><title>Edit person</title></head><body>
            <form action="/manage/edit/$wanted_id" method="post">
            First name: <input type="text" name="first_name" value="$first_name" /><br />
            Last name: <input type="text" name="last_name" value="$last_name" /><br />
            Email: <input type="text" name="email" value="$email" /><br />
            <input type="submit" name="submit" value="Save" />
            </form></body></html>~;

        $c->response->body( $body );
    }

}

sub delete : Local {
    my ( $self, $c, $wanted_id ) = @_;
    $c->model( 'DB' )->delete( $wanted_id );
    $c->res->redirect( "/manage" );
}

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

    my $members = $c->model( 'DB' )->retrieve;

    my $body = qq~<html><head><title>Persons list</title></head><body>
        <a href="/manage/add">Add new person</a><br /><table>~;

    for my $m ( @$members ) {
        $body .= qq~<tr>
            <th>$m->{id}</th>
            <td><a href="/manage/edit/$m->{id}">$m->{last_name}, $m->{first_name}</a></td>
            <td>$m->{email}</td>
            <td><a href="/manage/delete/$m->{id}">delete member</a></td>
        </tr>\n~;
    }

    $body .= "</table></body></html>";

    $c->response->body( $body );
}

1;
