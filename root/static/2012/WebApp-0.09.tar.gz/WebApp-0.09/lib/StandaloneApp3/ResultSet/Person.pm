package StandaloneApp3::ResultSet::Person;

use strict;
use warnings;
use base 'DBIx::Class::ResultSet';

sub add {
    my ( $self, $params ) = @_;
    $self->create( $params );
}

sub edit {
    my ( $self, $id, $params ) = @_;
    $self->find( $id )->update( $params );
}

sub del {
    my ( $self, $id ) = @_;
    $self->find( $id )->delete;
}

sub retrieve {
    my ( $self, $id ) = @_;
    my $members = $self->search( undef, { order_by => 'id' } );
    $members = $members->search( { id => $id } ) if $id;
    my @members = $members->all;
    return \@members;
}

1;
