
use strict;
use warnings;
use Config::JFDI;
use Getopt::Long;
use FindBin;
use lib "$FindBin::Bin/../lib";
use StandaloneApp3;

my ( $first_name, $last_name, $email );

GetOptions(
    'first-name=s' => \$first_name,
    'last-name=s' => \$last_name,
    'email=s' => \$email,
);

die "Please use --first-name, --last-name and --email parameters\n"
  unless $first_name and $last_name and $email;

my $config = Config::JFDI->new( name => 'WebApp', path => "$FindBin::Bin/.." )->get;
my $dsn = $config->{'Model::DB'}{connect_info}{dsn};

my $app = StandaloneApp3->connect( $dsn );

$app->resultset( 'Person' )->add( { first_name => $first_name,
  last_name => $last_name, email => $email } );
